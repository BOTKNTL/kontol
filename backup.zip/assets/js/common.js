(function () {
    var _UA = navigator.userAgent.toLocaleLowerCase();
    var device = { iphone: /iphone/.test(_UA), ipad: /ipad/.test(_UA), android: /android/.test(_UA), mobile: /mobile/.test(_UA), windowsPhone: /windows phone/.test(_UA) };
    var isSP = function () { return (device.iphone || (device.android && device.mobile) || device.windowsPhone); };
    if (isSP()) {
        location.href = '/sp' + location.pathname;
    }
})();
$(function () {
    var $win = $(window);
    var $globalNav = $('#con-header .global-nav');
    var $fixNav = $('#con-header-fix');
    var openFixNav = false;
    $('.totop').on('click', function () {
        TweenMax.to(window, 0.5, { scrollTo: 0, ease: Cubic.easeOut });
        return false;
    });
    if ($('.lower').length) {
        $win.on('scroll', _.throttle(function () {
            var st = $win.scrollTop();
            if (st > 150 && !openFixNav) {
                openFixNav = true;
                TweenMax.to($fixNav, 0.2, { top: 0, ease: Cubic.easeOut });
            }
            else if (st < 150 && openFixNav) {
                openFixNav = false;
                TweenMax.to($fixNav, 0.2, { top: -70, ease: Cubic.easeOut });
            }
        }, 10));
        _.each([$globalNav, $fixNav], function ($nav) {
            var $rec = $nav.find('.recruit-link');
            $nav.find('a.recruit').on({
                mouseover: function () {
                    TweenMax.set($rec, { y: -5 });
                    TweenMax.to($rec, 0.2, { y: 0, autoAlpha: 1, ease: Cubic.easeOut });
                }
            });
            $rec.on({
                mouseleave: function () {
                    TweenMax.to($rec, 0.2, { y: -5, autoAlpha: 0, ease: Cubic.easeOut });
                }
            });
        });
    }
});
