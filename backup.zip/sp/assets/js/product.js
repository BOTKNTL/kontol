$(function () {
    var list = [].slice.call(document.querySelectorAll('.products li'));
    var li = [];
    do {
        li = list.splice(0, 2);
        var max = false;
        var height = 0;
        _.every(li, function (o) {
            var h = $(o).height() + 15;
            if (o.className == 'cat2') {
                max = true;
                h += 10;
            }
            height = Math.max(height, h);
            return true;
        });
        _.each(li, function (o) {
            o.style.height = height + 'px';
        });
    } while (li.length);
});
