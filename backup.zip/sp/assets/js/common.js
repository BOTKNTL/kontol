(function () {
    var _UA = navigator.userAgent.toLocaleLowerCase();
    var device = { iphone: /iphone/.test(_UA), ipad: /ipad/.test(_UA), android: /android/.test(_UA), mobile: /mobile/.test(_UA), windowsPhone: /windows phone/.test(_UA) };
    var isSP = function () { return (device.iphone || (device.android && device.mobile) || device.windowsPhone); };
    if (!isSP()) {
        location.href = location.pathname.replace(/^\/sp/, '');
    }
})();
$(function () {
    var $body = $('body');
    var $nav = $('#nav-global');
    var $container = $('#container');
    $('.totop').on('click', function () {
        TweenMax.to(window, 0.5, { scrollTo: 0, ease: Cubic.easeOut });
        return false;
    });
    $('#con-header .menu').on('touchend', function () {
        $body.toggleClass('nav-mode');
        if ($body.hasClass('nav-mode')) {
            $nav.block();
            $container.on('touchmove', function () {
                return false;
            });
        }
        else {
            $container.off('touchmove');
            TweenMax.set($nav, { display: 'none', delay: 0.4 });
        }
        return false;
    });
});
