var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var orib;
(function (orib) {
    var ScrollController = util.ScrollController;
    var $win, $doc;
    var winH = 0;
    var pause;
    var MainView = (function (_super) {
        __extends(MainView, _super);
        function MainView() {
            _super.call(this);
            this._index = 0;
            this._z = 2;
            this.$view = $('section.main');
            this._init();
            this._showPage1();
            this._startTimer();
        }
        MainView.prototype._init = function () {
            var _this = this;
            this._$img = this.$view.find('.image');
            this._$visual = this.$view.find('.visual');
            this._$page = this.$view.find('.page-index li');
            $win.on('resize', function () {
                winH = $win.height();
                _this.$view.height(winH);
                _this._$img.width(Math.max($win.width(), 1280));
            }).trigger('resize');
            this._$page.on('click', function (e) {
                var $btn = $(e.target);
                if (!$btn.hasClass('active')) {
                    _this._index = _int10($btn.attr('data-idx')) - 1;
                    clearInterval(_this._timer);
                    _this._next();
                    _this._startTimer();
                }
                return false;
            });
        };
        MainView.prototype._startTimer = function () {
            var _this = this;
            this._timer = setInterval(function () {
                if (!pause) {
                    _this._next();
                }
            }, 7000);
        };
        MainView.prototype._next = function () {
            this._index = (this._index + 1) % 2;
            switch (this._index) {
                case 0:
                    this._showPage1();
                    break;
                case 1:
                    this._showPage2();
                    break;
            }
        };
        MainView.prototype._showPage1 = function () {
            this._$page.removeClass().eq(0).addClass('active');
            var $v = this._$visual.eq(0).z(this._z++);
            var $c = $v.find('.catch');
            var $scl = this.$view.find('.scroll');
            TweenMax.set($v, { width: 0 });
            TweenMax.set($c, { autoAlpha: 0, scale: 1.1 });
            TweenMax.to($v, 0.6, { width: '100%', ease: Cubic.easeInOut });
            TweenMax.to($c, 0.7, { delay: 0.8, scale: 1, autoAlpha: 1, ease: Cubic.easeOut });
            new TimelineMax()
                .to($scl, 0.15, { delay: 1.5, y: -15, ease: Cubic.easeOut })
                .to($scl, 0.2, { y: 0, ease: Cubic.easeIn })
                .to($scl, 0.15, { y: -20, ease: Cubic.easeOut })
                .to($scl, 0.2, { y: 0, ease: Cubic.easeIn });
        };
        MainView.prototype._showPage2 = function () {
            this._$page.removeClass().eq(1).addClass('active');
            var $v = this._$visual.eq(1).z(this._z++);
            var $c = $v.find('.catch');
            TweenMax.set($v, { width: 0 });
            TweenMax.set($c, { autoAlpha: 0, scale: 0.5 });
            TweenMax.to($v, 0.6, { width: '100%', ease: Cubic.easeInOut });
            TweenMax.to($c, 0.5, { delay: 0.6, scale: 1, autoAlpha: 1, ease: Back.easeOut });
        };
        return MainView;
    }(util.View));
    var Navigation = (function (_super) {
        __extends(Navigation, _super);
        function Navigation() {
            _super.call(this);
            this.openFixNav = false;
            this.$view = $('#con-header-fix');
            this._init();
            ScrollController.instance.add(this);
        }
        Navigation.prototype._init = function () {
            _.each([this.$view, $('#con-header-top')], function ($nav, i) {
                var $rec = $nav.find('.recruit-link');
                var pos = 5 * (i ? 1 : -1);
                $nav.find('a.recruit').on({
                    mouseover: function () {
                        TweenMax.set($rec, { y: pos });
                        TweenMax.to($rec, 0.2, { y: 0, autoAlpha: 1, ease: Cubic.easeOut });
                    }
                });
                $rec.on({
                    mouseleave: function () {
                        TweenMax.to($rec, 0.2, { y: pos, autoAlpha: 0, ease: Cubic.easeOut });
                    }
                });
            });
        };
        Navigation.prototype.onScroll = function (st) {
            if (st > winH && !this.openFixNav) {
                this.openFixNav = true;
                TweenMax.to(this.$view, 0.2, { top: 0, ease: Cubic.easeOut });
            }
            else if (st < winH && this.openFixNav) {
                this.openFixNav = false;
                TweenMax.to(this.$view, 0.2, { top: -70, ease: Cubic.easeOut });
            }
        };
        return Navigation;
    }(util.View));
    var ContentView = (function (_super) {
        __extends(ContentView, _super);
        function ContentView(sel) {
            _super.call(this);
            this._isActive = {};
            this.$view = $(sel);
            this._$title = this.$view.find('.section-title h2');
            this._$sub = this.$view.find('.section-title span');
            this._$lead = this.$view.find('.section-lead');
            this._init();
        }
        ContentView.prototype._showTitle = function () {
            TweenMax.set([this._$title, this._$sub], { autoAlpha: 0, y: 30 });
            TweenMax.set(this._$lead, { autoAlpha: 0 });
            TweenMax.to(this._$title, 0.4, { y: 0, autoAlpha: 1, ease: Cubic.easeOut });
            TweenMax.to(this._$sub, 0.4, { delay: 0.1, y: 0, autoAlpha: 1, ease: Cubic.easeOut });
            TweenMax.to(this._$lead, 0.6, { delay: 0.5, autoAlpha: 1 });
        };
        ContentView.prototype._hideTitle = function () {
            TweenMax.set([this._$title, this._$sub], { autoAlpha: 0, y: 30 });
            TweenMax.set(this._$lead, { autoAlpha: 0 });
        };
        ContentView.prototype._init = function () { };
        ContentView.prototype.onScroll = function (st) { };
        return ContentView;
    }(util.View));
    var thoughtView = (function (_super) {
        __extends(thoughtView, _super);
        function thoughtView() {
            _super.apply(this, arguments);
        }
        thoughtView.prototype._init = function () {
            this._$pic = this.$view.find('.pictures p');
        };
        thoughtView.prototype.onScroll = function (st) {
            if (winH - 300 < st && !this._isActive.title) {
                this._isActive.title = true;
                this._showTitle();
            }
            if (winH < st && !this._isActive.pic) {
                this._isActive.pic = true;
                this._showPhoto();
            }
        };
        thoughtView.prototype._showPhoto = function () {
            TweenMax.set(this._$pic, { x: 100, autoAlpha: 0 });
            TweenMax.set(this._$pic.eq(0), { x: -100 });
            TweenMax.staggerTo(this._$pic, 0.6, { x: 0, autoAlpha: 1, ease: Cubic.easeOut }, 0.1);
        };
        return thoughtView;
    }(ContentView));
    var qualityView = (function (_super) {
        __extends(qualityView, _super);
        function qualityView() {
            _super.apply(this, arguments);
        }
        qualityView.prototype._init = function () {
            this._$list = this.$view.find('.qualitylist li');
        };
        qualityView.prototype.onScroll = function (st) {
            if (winH + 900 < st && !this._isActive.title) {
                this._isActive.title = true;
                this._showTitle();
            }
            if (winH + 1200 < st && !this._isActive.list) {
                this._isActive.list = true;
                this._showList();
            }
        };
        qualityView.prototype._showList = function () {
            TweenMax.set(this._$list, { scale: 0.9, autoAlpha: 0 });
            TweenMax.staggerTo(this._$list, 0.4, { scale: 1, autoAlpha: 1, ease: Cubic.easeOut }, 0.1);
        };
        return qualityView;
    }(ContentView));
    var marketshareView = (function (_super) {
        __extends(marketshareView, _super);
        function marketshareView() {
            _super.apply(this, arguments);
        }
        marketshareView.prototype._init = function () {
            this._$performance = this.$view.find('.performance');
        };
        marketshareView.prototype.onScroll = function (st) {
            if (winH + 1850 < st && !this._isActive.title) {
                this._isActive.title = true;
                this._showTitle();
            }
            if (winH + 2250 < st && !this._isActive.perform) {
                this._isActive.perform = true;
                this._showPerformance();
            }
        };
        marketshareView.prototype._showPerformance = function () {
            TweenMax.set(this._$performance, { autoAlpha: 0 });
            TweenMax.to(this._$performance, 0.4, { autoAlpha: 1 });
        };
        return marketshareView;
    }(ContentView));
    var productView = (function (_super) {
        __extends(productView, _super);
        function productView() {
            _super.apply(this, arguments);
        }
        productView.prototype.onScroll = function (st) {
            if (winH + 3000 < st && !this._isActive.image) {
                this._isActive.image = true;
                this._showImage();
            }
            if (winH + 3300 < st && !this._isActive.title) {
                this._isActive.title = true;
                this._showTitle();
            }
            if (winH + 3800 < st && !this._isActive.list) {
                this._isActive.list = true;
                this._showProduct();
            }
        };
        productView.prototype._showImage = function () {
            TweenMax.to(this.$view.find('.image p'), 0.4, { borderWidth: 0, ease: Cubic.easeInOut });
        };
        productView.prototype._showProduct = function () {
            TweenMax.to(this.$view.find('.product-list'), 0.5, { autoAlpha: 1 });
        };
        return productView;
    }(ContentView));
    var Contents = (function () {
        function Contents() {
            this._thought = new thoughtView('section.thought');
            this._quality = new qualityView('section.quality');
            this._marketshare = new marketshareView('section.marketshare');
            this._product = new productView('section.product');
            ScrollController.instance.add(this);
        }
        Contents.prototype.onScroll = function (st) {
            this._thought.onScroll(st);
            this._quality.onScroll(st);
            this._marketshare.onScroll(st);
            this._product.onScroll(st);
        };
        return Contents;
    }());
    var TopApp = (function (_super) {
        __extends(TopApp, _super);
        function TopApp() {
            _super.apply(this, arguments);
        }
        TopApp.prototype.ready = function () {
            $doc = $(document);
            $win = $(window);
            $win.on({
                blur: function () {
                    pause = true;
                },
                focus: function () {
                    pause = false;
                }
            });
            $('section.main').height($win.height());
            ScrollController.init(10);
        };
        TopApp.prototype.load = function () {
            new Navigation();
            new MainView();
            new Contents();
            ScrollController.instance.start();
            $win.on('mousewheel', function (e) {
                var st = $win.scrollTop();
                var pos = st - _wrap(-200, 200, e.deltaY * e.deltaFactor);
                TweenMax.to(window, 0.3, { scrollTo: pos, ease: Expo.easeOut });
                return false;
            });
        };
        return TopApp;
    }(util.AppMain));
    orib.TopApp = TopApp;
})(orib || (orib = {}));
new orib.TopApp();
