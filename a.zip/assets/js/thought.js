var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var orib;
(function (orib) {
    var ScrollController = util.ScrollController;
    var $win, $doc;
    var winH = 0;
    var docH = 0;
    var preload = [
        { src: '../assets/img/thought/bg_1.jpg' }
    ];
    var Background = (function () {
        function Background() {
            var _this = this;
            this._$view = $('#background');
            this._$bg = this._$view.find('p');
            this._$line = this._$view.find('div');
            this._opened = [];
            ScrollController.instance.add(this);
            $win.on('resize', function () {
                winH = $win.height();
                var y = _wrap(-100, 0, winH - 1000);
                _this._$bg.y(y);
                var pos = Math.min(-(0 - 6300), 0);
                _this._$view.y(pos);
            }).trigger('resize');
        }
        Background.prototype.appear = function () {
            TweenMax.to(this._$bg.eq(0), 0.5, { autoAlpha: 1 });
            TweenMax.to(this._$line, 1, { delay: 2, autoAlpha: 1 });
        };
        Background.prototype.onScroll = function (st) {
            var size = [0, 500, 1400, 2300, 3300, 4100, 5100, 6100];
            for (var i = 0; i < 8; i++) {
                if (st > size[i] && !this._opened[i]) {
                    this._opened[i] = true;
                    TweenMax.to(this._$bg[i], 1, { autoAlpha: 1 });
                }
                else if (st < size[i] && this._opened[i]) {
                    this._opened[i] = false;
                    TweenMax.to(this._$bg[i], 0.3, { autoAlpha: 0 });
                }
            }
            var pos = Math.min(-(st - 6300), 0);
            this._$view.y(pos);
        };
        return Background;
    }());
    var Section = (function (_super) {
        __extends(Section, _super);
        function Section(controller, sel) {
            _super.call(this);
            this.$view = $(sel);
            this._$title = this.$view.find('dt');
            this._$text = this.$view.find('dd');
            this._$pic = this.$view.find('.pic li');
            this._init();
        }
        Section.prototype._init = function () {
        };
        Section.prototype.appear = function () {
            if (!this._isActive) {
                this._isActive = true;
                TweenMax.set([this._$title, this._$text, this._$pic], { y: 20, autoAlpha: 0 });
                TweenMax.to(this._$title, 0.5, { y: 0, autoAlpha: 1, ease: Cubic.easeOut });
                TweenMax.to(this._$text, 0.5, { delay: 0.4, y: 0, autoAlpha: 1, ease: Cubic.easeOut });
                TweenMax.staggerTo(this._$pic, 0.5, { delay: 1, y: 0, autoAlpha: 1, ease: Cubic.easeOut }, 0.2);
            }
            return this;
        };
        Section.prototype.disappear = function () {
            if (this._isActive) {
                this._isActive = false;
                TweenMax.set([this._$title, this._$text, this._$pic], { y: 20, autoAlpha: 0 });
            }
            return this;
        };
        return Section;
    }(util.Page));
    var SectionFirst = (function (_super) {
        __extends(SectionFirst, _super);
        function SectionFirst() {
            _super.apply(this, arguments);
        }
        SectionFirst.prototype._init = function () {
            this._$chr = this.$view.find('p');
            _.each(this._$chr, function (o, i) {
                if (i == 0 || i % 4 == 0) {
                    TweenMax.set(o, { y: -20 });
                }
                else if (i % 4 == 1) {
                    TweenMax.set(o, { x: 10 });
                }
                else if (i % 4 == 2) {
                    TweenMax.set(o, { y: 20 });
                }
                else if (i % 4 == 3) {
                    TweenMax.set(o, { x: -10 });
                }
            });
        };
        SectionFirst.prototype.appear = function () {
            TweenMax.staggerTo(this._$chr, 0.5, { x: 0, y: 0, autoAlpha: 1, delay: 1, ease: Cubic.easeOut }, 0.05);
            var $scl = this.$view.find('span');
            new TimelineMax()
                .to($scl, 0.15, { delay: 2.5, y: -15, autoAlpha: 1, ease: Cubic.easeOut })
                .to($scl, 0.2, { y: 0, ease: Cubic.easeIn })
                .to($scl, 0.15, { y: -20, ease: Cubic.easeOut })
                .to($scl, 0.2, { y: 0, ease: Cubic.easeIn })
                .to($scl, 0.3, { delay: 3, autoAlpha: 0 });
            return this;
        };
        return SectionFirst;
    }(Section));
    var SectionLast = (function (_super) {
        __extends(SectionLast, _super);
        function SectionLast() {
            _super.apply(this, arguments);
        }
        SectionLast.prototype._init = function () {
            this._$catch = this.$view.find('.catch');
            this._$summary = this.$view.find('.summary');
            this._diff = 0;
            if (window.innerHeight < 800) {
                this._diff = (800 - window.innerHeight);
                this.$view.height('+=' + this._diff);
            }
        };
        SectionLast.prototype.appear = function () {
            if (!this._isActive) {
                this._isActive = true;
                TweenMax.set([this._$title, this._$text], { y: 20, autoAlpha: 0 });
                TweenMax.set(this._$catch, { scale: 0.8, autoAlpha: 0 });
                TweenMax.to(this._$title, 0.5, { y: 0, autoAlpha: 1, ease: Cubic.easeOut });
                TweenMax.to(this._$text, 0.5, { delay: 0.4, y: 0, autoAlpha: 1, ease: Cubic.easeOut });
            }
            return this;
        };
        SectionLast.prototype.onScroll = function (st) {
            if (6300 + this._diff <= st && !this._fix) {
                this._fix = true;
                this.$view.y(200 - this._diff).addClass('fixed');
            }
            else if (6300 + this._diff > st && this._fix) {
                this._fix = false;
                this.$view.removeClass('fixed').y(6400);
            }
            if (st + window.innerHeight == docH) {
                TweenMax.to(this._$catch, 0.5, { scale: 1, autoAlpha: 1, ease: Back.easeOut });
            }
        };
        SectionLast.prototype.disappear = function () {
            if (this._isActive) {
                this._isActive = false;
                TweenMax.set([this._$title, this._$text], { y: 20, autoAlpha: 0 });
                TweenMax.set(this._$catch, { scale: 0.8, autoAlpha: 0 });
            }
            return this;
        };
        return SectionLast;
    }(Section));
    var Controller = (function () {
        function Controller() {
            ScrollController.instance.add(this);
            this._sec00 = new SectionFirst(this, 'section.sec00');
            this._sec01 = new Section(this, 'section.sec01');
            this._sec02 = new Section(this, 'section.sec02');
            this._sec03 = new Section(this, 'section.sec03');
            this._sec04 = new SectionLast(this, 'section.sec04');
            this._background = new Background();
            this._sec00.appear();
            this._background.appear();
            $win.on('mousewheel', function (e) {
                var st = $win.scrollTop();
                var dist = _wrap(-75, 200, e.deltaY * e.deltaFactor);
                var pos = st - dist;
                TweenMax.to(window, .4, { scrollTo: pos, ease: Expo.easeOut });
                return false;
            });
        }
        Controller.prototype.onScroll = function (st) {
            if (st > 700) {
                this._sec01.appear();
            }
            if (st > 2450) {
                this._sec02.appear();
            }
            if (st > 4250) {
                this._sec03.appear();
            }
            if (st > 5900) {
                this._sec04.appear();
            }
            if (100 > st) {
                this._sec01.disappear();
                this._sec02.disappear();
                this._sec03.disappear();
                this._sec04.disappear();
            }
            this._sec04.onScroll(st);
        };
        return Controller;
    }());
    var ThoughtApp = (function (_super) {
        __extends(ThoughtApp, _super);
        function ThoughtApp() {
            _super.apply(this, arguments);
        }
        ThoughtApp.prototype.ready = function () {
            $doc = $(document);
            $win = $(window);
            $win.on('mousewheel', function () { return false; });
            ScrollController.init();
        };
        ThoughtApp.prototype.load = function () {
            docH = $doc.height();
            var preload = [];
            for (var i = 1; i <= 7; i++) {
                preload.push({ src: '../assets/img/thought/bg_' + i + '.jpg' });
            }
            new util.ImageAssets().setup(preload).exec().done(function () {
                window.scrollTo(0, 0);
                _.delay(function () {
                    ScrollController.instance.start();
                    $win.off('mousewheel');
                    new Controller();
                }, 1000);
            });
        };
        return ThoughtApp;
    }(util.AppMain));
    orib.ThoughtApp = ThoughtApp;
})(orib || (orib = {}));
new orib.ThoughtApp();
