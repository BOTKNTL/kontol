function initMap() {
    var place = [
        [34.4326441,135.3220235],
        [34.6657626,135.4958165],
        [34.4161259,135.3224244],
        [34.7174889,135.3352882],
        [34.6906384,135.624452],
        [34.8749624,135.7581157],
        [34.7492371,135.7711541]
    ];

    $('.gmap').each(function(i, elm){
        var latlng = {lat:place[i][0], lng:place[i][1]};
        var map = new google.maps.Map(elm, {
            center: latlng,
            scrollwheel: true,
            zoom: 11
        });
        new google.maps.Marker({
            position: latlng,
            map: map
        });
    });
}
