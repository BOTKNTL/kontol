var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MainView = (function (_super) {
    __extends(MainView, _super);
    function MainView() {
        _super.call(this);
        this._index = 0;
        this._z = 2;
        this.$view = $('section.main');
        this._init();
        this._showPage1();
        this._startTimer();
    }
    MainView.prototype._init = function () {
        var _this = this;
        this._$img = this.$view.find('.image');
        this._$visual = this.$view.find('.visual');
        this._$page = this.$view.find('.page-index li');
        this._$page.on('click', function (e) {
            var $btn = $(e.target);
            if (!$btn.hasClass('active')) {
                _this._index = _int10($btn.attr('data-idx')) - 1;
                clearInterval(_this._timer);
                _this._next();
                _this._startTimer();
            }
            return false;
        });
    };
    MainView.prototype._startTimer = function () {
        var _this = this;
        this._timer = setInterval(function () {
            _this._next();
        }, 7000);
    };
    MainView.prototype._next = function () {
        this._index = (this._index + 1) % 2;
        switch (this._index) {
            case 0:
                this._showPage1();
                break;
            case 1:
                this._showPage2();
                break;
        }
    };
    MainView.prototype._showPage1 = function () {
        this._$page.removeClass().eq(0).addClass('active');
        var $v = this._$visual.eq(0).z(this._z++);
        var $c = $v.find('.catch');
        var $scl = this.$view.find('.scroll');
        TweenMax.set($v, { width: 0 });
        TweenMax.set($c, { autoAlpha: 0, scale: 1.1 });
        TweenMax.to($v, 0.6, { width: '100%', ease: Cubic.easeInOut });
        TweenMax.to($c, 0.7, { delay: 0.8, scale: 1, autoAlpha: 1, ease: Cubic.easeOut });
        new TimelineMax()
            .to($scl, 0.15, { delay: 1.5, y: -15, ease: Cubic.easeOut })
            .to($scl, 0.2, { y: 0, ease: Cubic.easeIn })
            .to($scl, 0.15, { y: -20, ease: Cubic.easeOut })
            .to($scl, 0.2, { y: 0, ease: Cubic.easeIn });
    };
    MainView.prototype._showPage2 = function () {
        this._$page.removeClass().eq(1).addClass('active');
        var $v = this._$visual.eq(1).z(this._z++);
        var $c = $v.find('.catch');
        TweenMax.set($v, { width: 0 });
        TweenMax.set($c, { autoAlpha: 0, scale: 0.5 });
        TweenMax.to($v, 0.6, { width: '100%', ease: Cubic.easeInOut });
        TweenMax.to($c, 0.5, { delay: 0.6, scale: 1, autoAlpha: 1, ease: Back.easeOut });
    };
    return MainView;
}(util.View));
var ProductList = (function () {
    function ProductList() {
        var _this = this;
        var products = [].slice.call(document.querySelectorAll('.product-list'));
        _.each(products, function (list) {
            _this._adjust([].slice.call($(list).find('ul li')));
        });
    }
    ProductList.prototype._adjust = function (list) {
        var li = [];
        do {
            li = list.splice(0, 2);
            var height = 0;
            _.every(li, function (o) {
                var h = $(o).height() + 15;
                height = Math.max(height, h);
                return true;
            });
            _.each(li, function (o) {
                o.style.height = height + 'px';
            });
        } while (li.length);
    };
    return ProductList;
}());
var TopApp = (function (_super) {
    __extends(TopApp, _super);
    function TopApp() {
        _super.apply(this, arguments);
    }
    TopApp.prototype.load = function () {
        new MainView();
        new ProductList();
    };
    return TopApp;
}(util.AppMain));
new TopApp();
